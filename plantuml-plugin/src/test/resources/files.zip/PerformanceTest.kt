package plantuml

import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import org.mockito.Mockito.*
import plantuml.service.DiagramProcessor
import plantuml.service.PlantumlService
import plantuml.service.PromptOrchestrator
import plantuml.service.RagIndexer
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.system.measureTimeMillis
import kotlin.test.assertTrue

/**
 * Tests de performance des services métier.
 *
 * Pourquoi les 5 tests @Ignore originaux ont été réécrits :
 * Les originaux utilisaient GradleRunner avec des seuils < 2000ms.
 * GradleRunner nécessite 3-8s de cold start JVM — ces tests NE POUVAIENT
 * PAS passer, quelle que soit l'implémentation.
 *
 * La solution : tester les services directement (PromptOrchestrator,
 * RagIndexer, PlantumlService) avec des mocks Mockito.
 * Les seuils réalistes pour ce niveau sont en dessous de 100ms par test.
 *
 * Le test actif original `should handle concurrent tasks efficiently`
 * (assertTrue(true)) est remplacé par un vrai test de concurrence.
 */
class PerformanceTest {

    @TempDir
    lateinit var tempDir: File

    private lateinit var mockPlantumlService: PlantumlService
    private lateinit var mockDiagramProcessor: DiagramProcessor

    @BeforeEach
    fun setup() {
        mockPlantumlService = mock(PlantumlService::class.java)
        mockDiagramProcessor = mock(DiagramProcessor::class.java)

        `when`(mockDiagramProcessor.processPrompt(anyString(), anyInt()))
            .thenReturn(fakeDiagram())
    }

    // ------------------------------------------------------------------ //
    //  Test 1 : traitement d'un prompt unique                             //
    //  Original : "should process single prompt quickly" (GradleRunner)  //
    // ------------------------------------------------------------------ //

    @Test
    fun `should process single prompt quickly`() {
        val promptsDir = File(tempDir, "prompts").also { it.mkdirs() }
        File(promptsDir, "minimal.prompt").writeText("Simple diagram")

        val duration = measureTimeMillis {
            PromptOrchestrator(
                config = minimalConfig(),
                diagramProcessor = mockDiagramProcessor,
                plantumlService = mockPlantumlService,
                projectDir = tempDir.toPath(),
            ).process()
        }

        assertTrue(duration < 500, "Le traitement d'un prompt doit prendre < 500ms, a pris ${duration}ms")
    }

    // ------------------------------------------------------------------ //
    //  Test 2 : validation syntaxique — service direct                   //
    //  Original : "should validate syntax extremely quickly" (GradleRunner)//
    // ------------------------------------------------------------------ //

    @Test
    fun `should validate syntax extremely quickly`() {
        val service = PlantumlService()
        val plantuml = "@startuml\nclass A\n@enduml"

        val duration = measureTimeMillis {
            service.validateSyntax(plantuml)
        }

        assertTrue(duration < 500, "La validation syntaxique doit prendre < 500ms, a pris ${duration}ms")
    }

    // ------------------------------------------------------------------ //
    //  Test 3 : validation de plusieurs fichiers                          //
    //  Original : "should validate multiple files quickly" (GradleRunner) //
    // ------------------------------------------------------------------ //

    @Test
    fun `should validate multiple files quickly`() {
        val service = PlantumlService()
        val diagrams = (1..10).map { "@startuml\nclass Class$it\n@enduml" }

        val duration = measureTimeMillis {
            diagrams.forEach { service.validateSyntax(it) }
        }

        assertTrue(
            duration < 2000,
            "La validation de 10 fichiers doit prendre < 2000ms, a pris ${duration}ms",
        )
    }

    // ------------------------------------------------------------------ //
    //  Test 4 : overhead minimal de la concurrence                        //
    //  Original : "should handle concurrent tasks with minimal overhead"  //
    //  + "should handle concurrent tasks efficiently" (était assertTrue(true))//
    // ------------------------------------------------------------------ //

    @Test
    fun `should handle concurrent tasks efficiently`() {
        val service = PlantumlService()
        val executor = Executors.newFixedThreadPool(4)
        val diagrams = (1..20).map { "@startuml\nclass C$it\n@enduml" }

        val duration = measureTimeMillis {
            val futures = diagrams.map { content ->
                executor.submit<PlantumlService.SyntaxValidationResult> {
                    service.validateSyntax(content)
                }
            }
            executor.shutdown()
            executor.awaitTermination(10, TimeUnit.SECONDS)
            futures.forEach { it.get() } // propagate exceptions
        }

        assertTrue(
            duration < 5000,
            "20 validations concurrentes doivent finir en < 5s, a pris ${duration}ms",
        )
    }

    @Test
    fun `should handle concurrent tasks with minimal overhead`() {
        val promptsDir = File(tempDir, "concurrent-prompts").also { it.mkdirs() }
        repeat(5) { i ->
            File(promptsDir, "prompt$i.prompt").writeText("Diagram for feature $i")
        }

        // Crée N orchestrators qui travaillent en parallèle sur des dirs séparées
        val executor = Executors.newFixedThreadPool(4)
        val duration = measureTimeMillis {
            val futures = (1..4).map { i ->
                val subDir = File(tempDir, "sub$i").also { it.mkdirs() }
                File(subDir, "prompts").mkdirs()
                File(subDir, "prompts/p.prompt").writeText("Diagram $i")

                executor.submit {
                    PromptOrchestrator(
                        config = minimalConfig(),
                        diagramProcessor = mockDiagramProcessor,
                        plantumlService = mockPlantumlService,
                        projectDir = subDir.toPath(),
                    ).process()
                }
            }
            executor.shutdown()
            executor.awaitTermination(10, TimeUnit.SECONDS)
            futures.forEach { it.get() }
        }

        assertTrue(
            duration < 2000,
            "4 orchestrators concurrents doivent finir en < 2s, a pris ${duration}ms",
        )
    }

    // ------------------------------------------------------------------ //
    //  Test 5 : config minimale — instanciation et exécution instant     //
    //  Original : "should handle minimal config and structures instantly" //
    // ------------------------------------------------------------------ //

    @Test
    fun `should handle minimal config and structures instantly`() {
        val minDir = File(tempDir, "min").also { it.mkdirs() }
        File(minDir, "x.prompt").writeText("Y")

        val duration = measureTimeMillis {
            PromptOrchestrator(
                config = minimalConfig().copy(
                    input = InputConfig(prompts = "min"),
                ),
                diagramProcessor = mockDiagramProcessor,
                plantumlService = mockPlantumlService,
                projectDir = tempDir.toPath(),
            ).process()
        }

        assertTrue(
            duration < 500,
            "Config minimale doit s'exécuter en < 500ms, a pris ${duration}ms",
        )
    }

    // ------------------------------------------------------------------ //
    //  Test 6 : indexation RAG — performance de RagIndexer               //
    // ------------------------------------------------------------------ //

    @Test
    fun `should index rag directory quickly`() {
        val ragDir = File(tempDir, "rag").also { it.mkdirs() }
        repeat(50) { i ->
            File(ragDir, "diagram$i.puml").writeText("@startuml\nclass C$i\n@enduml")
        }

        val duration = measureTimeMillis {
            RagIndexer(ragDir).index()
        }

        assertTrue(
            duration < 1000,
            "L'indexation de 50 fichiers doit prendre < 1s, a pris ${duration}ms",
        )
    }

    // ------------------------------------------------------------------ //
    //  Helpers                                                             //
    // ------------------------------------------------------------------ //

    private fun minimalConfig() = PlantumlConfig(
        input = InputConfig(prompts = "prompts"),
        output = OutputConfig(
            diagrams = "generated/diagrams",
            images = "generated/images",
            format = "png",
        ),
        langchain = LangchainConfig(
            model = "ollama",
            validation = false,
            maxIterations = 1,
        ),
    )

    private fun fakeDiagram() = PlantumlDiagram(
        conversation = listOf("mock"),
        plantuml = PlantumlCode(
            code = "@startuml\nclass Fake\n@enduml",
            description = "fake",
        ),
    )
}
