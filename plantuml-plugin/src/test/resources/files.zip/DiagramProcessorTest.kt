package plantuml.service

import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.ValueSource
import org.mockito.Mockito.*
import plantuml.PlantumlCode
import plantuml.PlantumlDiagram
import plantuml.ValidationFeedback
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * Tests unitaires de DiagramProcessor.
 *
 * Pourquoi les @Ignore originaux ont été retirés :
 * Le setup utilise DiagramProcessor(mockPlantumlService, null, null).
 * Avec chatModel=null, le processor active son stub interne qui génère
 * un diagramme déterministe sans appel réseau — tous les mocks Mockito
 * étaient déjà correctement configurés, seule l'implémentation du stub
 * devait être finalisée.
 */
class DiagramProcessorTest {

    private lateinit var mockPlantumlService: PlantumlService
    private lateinit var diagramProcessor: DiagramProcessor

    @BeforeEach
    fun setUp() {
        mockPlantumlService = mock(PlantumlService::class.java)
        // chatModel=null active le stub interne — pas d'appel réseau
        diagramProcessor = DiagramProcessor(mockPlantumlService, null, null)
    }

    // ------------------------------------------------------------------ //
    //  Test 1 : traitement d'un prompt avec mock LLM                     //
    // ------------------------------------------------------------------ //

    @Test
    fun `should process prompt with mock llm response`() {
        val prompt = "Create a user diagram"
        setupValidSyntaxMock()

        val result = diagramProcessor.processPrompt(prompt)

        assertNotNull(result)
        assertTrue(result.conversation.isNotEmpty(), "La conversation doit contenir au moins une entrée")
        assertTrue(result.plantuml.code.contains("@startuml"), "Le code doit contenir @startuml")
        assertTrue(result.plantuml.code.contains("@enduml"), "Le code doit contenir @enduml")
        assertTrue(
            result.plantuml.description.contains("Auto-generated diagram based on prompt: $prompt"),
            "La description doit référencer le prompt original",
        )
    }

    // ------------------------------------------------------------------ //
    //  Test 2 : scénarios de validation syntaxique (paramétrisé)         //
    // ------------------------------------------------------------------ //

    @ParameterizedTest
    @ValueSource(ints = [1, 2])
    fun `should handle syntax validation scenarios`(scenario: Int) {
        when (scenario) {
            1 -> testMaxIterationsExceeded()
            2 -> testIterateOnSyntaxErrors()
        }
    }

    private fun testMaxIterationsExceeded() {
        val prompt = "Create a user diagram"
        setupInvalidSyntaxMock()

        val result = diagramProcessor.processPrompt(prompt, maxIterations = 1)

        // Après épuisement des itérations sans syntaxe valide → null
        assertNull(result, "Devrait retourner null quand les itérations sont épuisées")
        verify(mockPlantumlService, times(1)).validateSyntax(anyString())
    }

    private fun testIterateOnSyntaxErrors() {
        val prompt = "Create a user diagram"
        setupInvalidThenValidSyntaxMock()

        val result = diagramProcessor.processPrompt(prompt, maxIterations = 2)

        assertNotNull(result, "Devrait réussir à la 2e itération")
        // L'historique des tentatives doit figurer dans la conversation
        assertTrue(result.conversation.size > 1, "La conversation doit avoir plus d'une entrée après retry")
        assertTrue(
            result.conversation.any { it.contains("->") },
            "La conversation doit contenir des échanges (->)",
        )
    }

    // ------------------------------------------------------------------ //
    //  Test 3 : validation de la qualité d'un diagramme                  //
    // ------------------------------------------------------------------ //

    @Test
    fun `should validate diagram quality`() {
        val diagram = PlantumlDiagram(
            conversation = listOf("Test conversation"),
            plantuml = PlantumlCode(
                code = "@startuml\nactor User\n@enduml",
                description = "Test diagram",
            ),
        )

        val result = diagramProcessor.validateDiagram(diagram)

        assertEquals(8, result.score, "Le score attendu est 8")
        assertNotNull(result.feedback, "Le feedback ne doit pas être null")
        assertEquals(3, result.recommendations.size, "Doit avoir exactement 3 recommandations")
    }

    // ------------------------------------------------------------------ //
    //  Test 4 : sauvegarde pour l'entraînement RAG                       //
    // ------------------------------------------------------------------ //

    @Test
    fun `should save for rag training`() {
        val diagram = PlantumlDiagram(
            conversation = listOf("Test conversation"),
            plantuml = PlantumlCode(
                code = "@startuml\nactor User\n@enduml",
                description = "Test diagram",
            ),
        )
        val validation = ValidationFeedback(
            score = 8,
            feedback = "Good diagram",
            recommendations = listOf("Add more details"),
        )

        // Ne doit pas lever d'exception
        diagramProcessor.saveForRagTraining(diagram, validation)
    }

    // ------------------------------------------------------------------ //
    //  Helpers Mockito                                                     //
    // ------------------------------------------------------------------ //

    private fun setupValidSyntaxMock() {
        `when`(mockPlantumlService.validateSyntax(anyString()))
            .thenReturn(PlantumlService.SyntaxValidationResult.Valid)
    }

    private fun setupInvalidSyntaxMock() {
        `when`(mockPlantumlService.validateSyntax(anyString()))
            .thenReturn(PlantumlService.SyntaxValidationResult.Invalid("Test error", "Stack trace"))
    }

    private fun setupInvalidThenValidSyntaxMock() {
        `when`(mockPlantumlService.validateSyntax(anyString()))
            .thenReturn(PlantumlService.SyntaxValidationResult.Invalid("Test error", "Stack trace"))
            .thenReturn(PlantumlService.SyntaxValidationResult.Valid)
    }
}
