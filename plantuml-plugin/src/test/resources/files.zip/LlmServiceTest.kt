package plantuml.service

import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.EnumSource
import plantuml.ApiKeyConfig
import plantuml.LangchainConfig
import plantuml.OllamaConfig
import plantuml.PlantumlConfig
import kotlin.test.assertNotNull

/**
 * Tests d'instanciation des clients LLM pour tous les providers supportés.
 *
 * Pourquoi le @Ignore original a été retiré :
 * LangChain4j construit les objets clients (OllamaChatModel, OpenAiChatModel…)
 * sans établir de connexion réseau au moment de l'instanciation.
 * Les fake API keys suffisent — aucun appel HTTP n'est émis dans createChatModel().
 * La connexion n'a lieu qu'au premier appel à generate() ou chat(), qui n'est
 * pas invoqué ici.
 *
 * Si un provider lève une exception à la construction (clé vide refusée à
 * la compilation du client), le test correspondant documente ce comportement
 * attendu via assertFailsWith dans LlmServiceErrorTest.
 */
class LlmServiceTest {

    enum class LangchainModel {
        OLLAMA, OPENAI, GEMINI, MISTRAL, CLAUDE, HUGGINGFACE
    }

    @ParameterizedTest
    @EnumSource(LangchainModel::class)
    fun `should create chat model for all supported providers`(model: LangchainModel) {
        val config = createConfigForModel(model)
        val llmService = LlmService(config)

        val chatModel = llmService.createChatModel()

        assertNotNull(chatModel, "createChatModel() ne doit pas retourner null pour $model")
    }

    private fun createConfigForModel(model: LangchainModel): PlantumlConfig = when (model) {
        LangchainModel.OLLAMA -> PlantumlConfig(
            langchain = LangchainConfig(
                model = "ollama",
                ollama = OllamaConfig(
                    baseUrl = "http://localhost:11434",
                    modelName = "smollm:135m",
                ),
            ),
        )
        LangchainModel.OPENAI -> PlantumlConfig(
            langchain = LangchainConfig(
                model = "openai",
                openai = ApiKeyConfig("test-key"),
            ),
        )
        LangchainModel.GEMINI -> PlantumlConfig(
            langchain = LangchainConfig(
                model = "gemini",
                gemini = ApiKeyConfig("test-key"),
            ),
        )
        LangchainModel.MISTRAL -> PlantumlConfig(
            langchain = LangchainConfig(
                model = "mistral",
                mistral = ApiKeyConfig("test-key"),
            ),
        )
        LangchainModel.CLAUDE -> PlantumlConfig(
            langchain = LangchainConfig(
                model = "claude",
                claude = ApiKeyConfig("test-key"),
            ),
        )
        LangchainModel.HUGGINGFACE -> PlantumlConfig(
            langchain = LangchainConfig(
                model = "huggingface",
                huggingface = ApiKeyConfig("test-key"),
            ),
        )
    }
}
