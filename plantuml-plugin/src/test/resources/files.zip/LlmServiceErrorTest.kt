package plantuml.service

import org.junit.jupiter.api.Test
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.MethodSource
import plantuml.ApiKeyConfig
import plantuml.LangchainConfig
import plantuml.PlantumlConfig
import kotlin.test.assertFailsWith
import kotlin.test.assertNotNull

/**
 * Tests de gestion d'erreurs de LlmService.
 *
 * Pourquoi les @Ignore originaux ont été retirés :
 *
 * Test 1 (paramétrisé) : les scénarios "invalid-api-key", "network-timeouts" et
 * "rate-limiting" testent uniquement que createChatModel() retourne un objet
 * non-null. LangChain4j ne valide pas la clé au moment de la construction du
 * client — la validation se fait au premier appel réseau.
 * Le scénario "unsupported-model" vérifie que le service gère un provider
 * inconnu (fallback ou exception explicite documentée).
 * Le scénario "fallback-default" vérifie que gemini sans apiKey n'empêche
 * pas la construction.
 *
 * Test 2 : IllegalArgumentException pour une clé Claude vide. Si l'implémentation
 * de LlmService ne lève pas cette exception, le test échoue et documente un
 * manque de validation — c'est un comportement voulu à spécifier.
 */
class LlmServiceErrorTest {

    companion object {
        @JvmStatic
        fun errorHandlingScenarios() = listOf(
            arrayOf("invalid-api-key", "openai", "invalid-key"),
            arrayOf("unsupported-model", "unsupported-model", ""),
            arrayOf("network-timeouts", "openai", "test-key"),
            arrayOf("rate-limiting", "mistral", "test-key"),
            arrayOf("fallback-default", "gemini", ""),
        )
    }

    @ParameterizedTest
    @MethodSource("errorHandlingScenarios")
    fun `should handle various error scenarios gracefully`(
        scenario: String,
        model: String,
        apiKey: String,
    ) {
        val config = createConfigForScenario(scenario, model, apiKey)
        val llmService = LlmService(config)

        // Pour les providers connus avec fake keys : createChatModel() doit réussir
        // (la validation réseau a lieu plus tard, au premier appel LLM).
        // Pour "unsupported-model" : soit retourne non-null avec fallback,
        // soit lève une exception explicite — dans tous les cas pas de crash silencieux.
        if (model == "unsupported-model") {
            // Comportement attendu : exception levée avec message clair,
            // ou chatModel non-null si un fallback est implémenté.
            runCatching { llmService.createChatModel() }
                .onSuccess { assertNotNull(it, "Fallback doit retourner un modèle non-null") }
                .onFailure { ex ->
                    // Exception acceptable — doit avoir un message explicatif
                    assertNotNull(ex.message, "L'exception doit avoir un message pour $scenario")
                }
        } else {
            val chatModel = llmService.createChatModel()
            assertNotNull(chatModel, "createChatModel() ne doit pas retourner null pour $scenario")
        }
    }

    @Test
    fun `should handle malformed configuration gracefully`() {
        // Clé Claude vide — LlmService doit rejeter cette configuration
        // car l'API Anthropic refusera toute requête sans clé valide.
        // Documenter ce rejet au niveau de createChatModel() est préférable
        // à un échec cryptique au premier appel réseau.
        val config = PlantumlConfig(
            langchain = LangchainConfig(
                model = "claude",
                claude = ApiKeyConfig(""),
            ),
        )
        val llmService = LlmService(config)

        assertFailsWith<IllegalArgumentException>(
            message = "LlmService doit lever IllegalArgumentException pour une clé Claude vide",
        ) {
            llmService.createChatModel()
        }
    }

    // ------------------------------------------------------------------ //
    //  Helpers                                                             //
    // ------------------------------------------------------------------ //

    private fun createConfigForScenario(
        scenario: String,
        model: String,
        apiKey: String,
    ): PlantumlConfig = when (scenario) {
        "invalid-api-key" -> PlantumlConfig(
            langchain = LangchainConfig(model = model, openai = ApiKeyConfig(apiKey)),
        )
        "unsupported-model" -> PlantumlConfig(
            langchain = LangchainConfig(model = model),
        )
        "network-timeouts" -> PlantumlConfig(
            langchain = LangchainConfig(model = model, openai = ApiKeyConfig(apiKey)),
        )
        "rate-limiting" -> PlantumlConfig(
            langchain = LangchainConfig(model = model, mistral = ApiKeyConfig(apiKey)),
        )
        "fallback-default" -> PlantumlConfig(
            langchain = LangchainConfig(model = model),
        )
        else -> PlantumlConfig()
    }
}
