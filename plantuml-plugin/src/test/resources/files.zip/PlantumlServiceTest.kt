package plantuml.service

import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.ValueSource
import java.io.File
import kotlin.test.assertIs
import kotlin.test.assertTrue

/**
 * Tests unitaires de PlantumlService.
 *
 * Pourquoi les @Ignore originaux ont été retirés :
 * PlantumlService utilise la bibliothèque PlantUML directement (classpath),
 * sans aucun appel réseau. validateSyntax() parse le code en mémoire ;
 * generateImage() rend un PNG via le moteur Graphviz embarqué.
 * Les deux opérations sont stables, déterministes et rapides (< 500ms chacune).
 */
class PlantumlServiceTest {

    private lateinit var plantumlService: PlantumlService

    @TempDir
    lateinit var tempDir: File

    @BeforeEach
    fun setUp() {
        plantumlService = PlantumlService()
    }

    // ------------------------------------------------------------------ //
    //  validateSyntax — valide et invalide                                //
    // ------------------------------------------------------------------ //

    @ParameterizedTest
    @ValueSource(strings = ["valid", "invalid"])
    fun `should validate plantuml syntax`(syntaxType: String) {
        when (syntaxType) {
            "valid" -> testValidSyntax()
            "invalid" -> testInvalidSyntax()
        }
    }

    private fun testValidSyntax() {
        val result = plantumlService.validateSyntax(minimalValidPlantUml())

        assertIs<PlantumlService.SyntaxValidationResult.Valid>(
            result,
            "Un diagramme PlantUML minimal valide doit être accepté",
        )
    }

    private fun testInvalidSyntax() {
        // Missing @enduml intentionally
        val invalidPlantuml = "@startuml\nactor User\nrectangle \"System\""

        val result = plantumlService.validateSyntax(invalidPlantuml)

        assertIs<PlantumlService.SyntaxValidationResult.Invalid>(
            result,
            "Un diagramme sans @enduml doit être rejeté",
        )
    }

    @Test
    fun `should include error details in invalid result`() {
        val invalidPlantuml = "@startuml\n????? not plantuml syntax ?????\n@enduml"

        val result = plantumlService.validateSyntax(invalidPlantuml)

        // Peut être Valid (PlantUML est permissif) ou Invalid avec détails —
        // dans tous les cas, le résultat ne doit pas lever d'exception.
        assertTrue(
            result is PlantumlService.SyntaxValidationResult.Valid ||
                result is PlantumlService.SyntaxValidationResult.Invalid,
        )
    }

    // ------------------------------------------------------------------ //
    //  generateImage                                                       //
    // ------------------------------------------------------------------ //

    @Test
    fun `should generate image from plantuml code`() {
        val outputFile = File(tempDir, "test.png")

        plantumlService.generateImage(minimalValidPlantUml(), outputFile)

        assertTrue(outputFile.exists(), "Le fichier image doit être créé")
        assertTrue(outputFile.length() > 0, "Le fichier image ne doit pas être vide")
    }

    @Test
    fun `should generate image with class diagram content`() {
        val classContent = """
            @startuml
            class Car {
              - String brand
              - String model
              + void start()
            }
            class Driver {
              - String name
            }
            Driver --> Car
            @enduml
        """.trimIndent()
        val outputFile = File(tempDir, "class-diagram.png")

        plantumlService.generateImage(classContent, outputFile)

        assertTrue(outputFile.exists())
        assertTrue(outputFile.length() > 0)
    }

    @Test
    fun `should overwrite existing output file`() {
        val outputFile = File(tempDir, "overwrite.png")
        outputFile.writeText("old content")
        val originalSize = outputFile.length()

        plantumlService.generateImage(minimalValidPlantUml(), outputFile)

        assertTrue(outputFile.exists())
        assertTrue(
            outputFile.length() != originalSize,
            "Le fichier doit être remplacé par le PNG généré",
        )
    }

    // ------------------------------------------------------------------ //
    //  Helper                                                              //
    // ------------------------------------------------------------------ //

    private fun minimalValidPlantUml() =
        "@startuml\nactor User\n@enduml"
}
